// Site configuration for TENG A SOCK - Premium Sock Brand

export interface SiteConfig {
  language: string;
  title: string;
  description: string;
}

export const siteConfig: SiteConfig = {
  language: "en",
  title: "TENG A SOCK | Premium Socks for Every Step",
  description: "Discover premium quality socks crafted with comfort, style, and sustainability in mind. From athletic to dress socks, elevate your everyday wear.",
};

// Navigation configuration
export interface NavLink {
  label: string;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  links: NavLink[];
  contactLabel: string;
  contactHref: string;
}

export const navigationConfig: NavigationConfig = {
  logo: "TENG A SOCK",
  links: [
    { label: "About", href: "#about" },
    { label: "Collections", href: "#collections" },
    { label: "Products", href: "#products" },
    { label: "Reviews", href: "#reviews" },
  ],
  contactLabel: "Shop Now",
  contactHref: "#shop",
};

// Hero section configuration
export interface HeroConfig {
  name: string;
  roles: string[];
  backgroundImage: string;
}

export const heroConfig: HeroConfig = {
  name: "TENG A SOCK",
  roles: ["Premium Quality", "Sustainable Materials", "Ultimate Comfort", "Modern Design"],
  backgroundImage: "/images/hero-bg.jpg",
};

// About section configuration
export interface AboutStat {
  value: string;
  label: string;
}

export interface AboutImage {
  src: string;
  alt: string;
}

export interface AboutConfig {
  label: string;
  description: string;
  experienceValue: string;
  experienceLabel: string;
  stats: AboutStat[];
  images: AboutImage[];
}

export const aboutConfig: AboutConfig = {
  label: "About Us",
  description: "At TENG A SOCK, we believe every step matters. Founded with a passion for quality craftsmanship and sustainable fashion, we create premium socks that combine comfort, durability, and contemporary style. Our mission is simple: to elevate the most overlooked essential in your wardrobe into a statement of personal style and conscious living.",
  experienceValue: "10+",
  experienceLabel: "Years of\nCrafting Comfort",
  stats: [
    { value: "50+", label: "Unique Designs" },
    { value: "1M+", label: "Happy Feet" },
    { value: "100%", label: "Satisfaction" },
  ],
  images: [
    { src: "/images/about-1.jpg", alt: "Premium sock craftsmanship" },
    { src: "/images/about-2.jpg", alt: "Sustainable materials" },
    { src: "/images/about-3.jpg", alt: "Modern sock designs" },
    { src: "/images/about-4.jpg", alt: "Comfortable fit" },
  ],
};

// Services section configuration - repurposed as Collections
export interface ServiceItem {
  iconName: string;
  title: string;
  description: string;
  image: string;
}

export interface ServicesConfig {
  label: string;
  heading: string;
  services: ServiceItem[];
}

export const servicesConfig: ServicesConfig = {
  label: "Collections",
  heading: "Explore Our Signature Collections",
  services: [
    {
      iconName: "Zap",
      title: "Athletic Series",
      description: "High-performance socks engineered for athletes. Moisture-wicking technology, arch support, and breathable mesh panels keep you moving comfortably.",
      image: "/images/service-1.jpg",
    },
    {
      iconName: "Briefcase",
      title: "Business Classic",
      description: "Elevate your professional attire with our premium dress socks. Crafted from fine merino wool and cotton blends for all-day comfort.",
      image: "/images/service-2.jpg",
    },
    {
      iconName: "Heart",
      title: "Everyday Essential",
      description: "Versatile, comfortable socks for daily wear. Available in a rainbow of colors to match any outfit or mood.",
      image: "/images/service-3.jpg",
    },
    {
      iconName: "Leaf",
      title: "Eco Collection",
      description: "Sustainably made from organic cotton and recycled materials. Good for your feet, great for the planet.",
      image: "/images/service-4.jpg",
    },
  ],
};

// Portfolio section configuration - repurposed as Products
export interface ProjectItem {
  title: string;
  category: string;
  year: string;
  image: string;
  featured?: boolean;
}

export interface PortfolioCTA {
  label: string;
  heading: string;
  linkText: string;
  linkHref: string;
}

export interface PortfolioConfig {
  label: string;
  heading: string;
  description: string;
  projects: ProjectItem[];
  cta: PortfolioCTA;
  viewAllLabel: string;
}

export const portfolioConfig: PortfolioConfig = {
  label: "Products",
  heading: "Featured Products",
  description: "Discover our most loved designs, carefully crafted for every occasion. From bold patterns to classic solids, find your perfect pair.",
  projects: [
    {
      title: "Midnight Stripe Set",
      category: "Dress Socks",
      year: "2024",
      image: "/images/portfolio-1.jpg",
      featured: true,
    },
    {
      title: "Neon Runner Pack",
      category: "Athletic",
      year: "2024",
      image: "/images/portfolio-2.jpg",
    },
    {
      title: "Pastel Dream Bundle",
      category: "Casual",
      year: "2024",
      image: "/images/portfolio-3.jpg",
    },
    {
      title: "Eco Earth Tones",
      category: "Sustainable",
      year: "2024",
      image: "/images/portfolio-4.jpg",
    },
    {
      title: "Holiday Special Edition",
      category: "Limited",
      year: "2024",
      image: "/images/portfolio-5.jpg",
      featured: true,
    },
  ],
  cta: {
    label: "Special Offer",
    heading: "Get 20% Off Your First Order",
    linkText: "Claim Discount",
    linkHref: "#shop",
  },
  viewAllLabel: "View All Products",
};

// Testimonials section configuration
export interface TestimonialItem {
  quote: string;
  author: string;
  role: string;
  company: string;
  image: string;
  rating: number;
}

export interface TestimonialsConfig {
  label: string;
  heading: string;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  label: "Reviews",
  heading: "What Our Customers Say",
  testimonials: [
    {
      quote: "I've never experienced such comfort in a sock before. The Athletic Series keeps my feet dry during marathon training. Absolutely worth every penny!",
      author: "Marcus Chen",
      role: "Marathon Runner",
      company: "NYC Running Club",
      image: "/images/testimonial-1.jpg",
      rating: 5,
    },
    {
      quote: "Finally, dress socks that don't fall down during long meetings. The quality is exceptional and they look fantastic with my suits.",
      author: "Sarah Williams",
      role: "Executive Director",
      company: "Finance Corp",
      image: "/images/testimonial-2.jpg",
      rating: 5,
    },
    {
      quote: "Love that they're eco-friendly without compromising on comfort. The colors are vibrant even after multiple washes. Highly recommend!",
      author: "Emma Rodriguez",
      role: "Sustainability Advocate",
      company: "Green Living",
      image: "/images/testimonial-3.jpg",
      rating: 5,
    },
  ],
};

// CTA section configuration
export interface CTAConfig {
  tags: string[];
  heading: string;
  description: string;
  buttonText: string;
  buttonHref: string;
  email: string;
  backgroundImage: string;
}

export const ctaConfig: CTAConfig = {
  tags: ["Premium Quality", "Free Shipping", "30-Day Returns"],
  heading: "Ready to Upgrade Your Sock Drawer?",
  description: "Join over a million happy customers who've discovered the TENG A SOCK difference. Free shipping on orders over $50.",
  buttonText: "Shop Now",
  buttonHref: "#shop",
  email: "hello@tengasock.com",
  backgroundImage: "/images/cta-bg.jpg",
};

// Footer section configuration
export interface FooterLinkColumn {
  title: string;
  links: { label: string; href: string }[];
}

export interface SocialLink {
  iconName: string;
  href: string;
  label: string;
}

export interface FooterConfig {
  logo: string;
  description: string;
  columns: FooterLinkColumn[];
  socialLinks: SocialLink[];
  newsletterHeading: string;
  newsletterDescription: string;
  newsletterButtonText: string;
  newsletterPlaceholder: string;
  copyright: string;
  credit: string;
}

export const footerConfig: FooterConfig = {
  logo: "TENG A SOCK",
  description: "Premium socks crafted with care. Comfort, style, and sustainability in every step.",
  columns: [
    {
      title: "Shop",
      links: [
        { label: "All Products", href: "#" },
        { label: "Athletic", href: "#" },
        { label: "Dress Socks", href: "#" },
        { label: "Casual", href: "#" },
        { label: "Gift Sets", href: "#" },
      ],
    },
    {
      title: "Company",
      links: [
        { label: "About Us", href: "#" },
        { label: "Sustainability", href: "#" },
        { label: "Careers", href: "#" },
        { label: "Press", href: "#" },
        { label: "Contact", href: "#" },
      ],
    },
    {
      title: "Support",
      links: [
        { label: "FAQ", href: "#" },
        { label: "Shipping", href: "#" },
        { label: "Returns", href: "#" },
        { label: "Size Guide", href: "#" },
        { label: "Track Order", href: "#" },
      ],
    },
  ],
  socialLinks: [
    { iconName: "Instagram", href: "https://instagram.com", label: "Instagram" },
    { iconName: "Facebook", href: "https://facebook.com", label: "Facebook" },
    { iconName: "Twitter", href: "https://twitter.com", label: "Twitter" },
    { iconName: "Youtube", href: "https://youtube.com", label: "YouTube" },
  ],
  newsletterHeading: "Stay in the Loop",
  newsletterDescription: "Subscribe for exclusive offers, new releases, and sock inspiration.",
  newsletterButtonText: "Subscribe",
  newsletterPlaceholder: "Enter your email",
  copyright: "© 2024 TENG A SOCK. All rights reserved.",
  credit: "Crafted with care for happy feet everywhere.",
};
